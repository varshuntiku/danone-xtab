import json
import logging
import httpx
class Simulator():
    def __init__(self,app_id,base_url,token) -> None:
        super().__init__()
        self.app_id = app_id
        self.baseurl= base_url
        self.token = token
        

    def get_scenario_data(self,name):
        try:
            url="{}/scenario/{}/{}/scenariodata".format(self.baseurl,self.app_id,name)
            headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}",
            }
            response = httpx.get(url=url, headers=headers,timeout = 20.0 )
            return json.loads(response.content)
        except Exception as ex:
           logging.exception(ex)

    def app_scenario_list(self):
        try:
            url="{}/scenario/{}/appscenarioslist".format(self.baseurl,self.app_id)
            headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}",
            }
            response = httpx.get(url=url, headers=headers,timeout = 20.0)
            return [row['name'] for row in json.loads(response.content)]
        except Exception as ex:
            logging.exception(ex)
    
    def slider(self,id,label,value,min,max,steps):
         slider_dict = {
            "input_type": "slider",
            "id": id,
            "label": label,
            "value": value,
            "min": min,
            "max": max,
            "steps": steps
         }
         return slider_dict
    
    def inputBox(self,id,label,value,min,max,steps):
        input_dict = {
           "input_type": "input",
            "id": id,
            "label": label,
            "value": value,
            "min": min,
            "max": max,
            "steps": steps
                   }
        return input_dict
    
    def radio(self,id,label,options):
        radio_dict = {
           "input_type": "radio",
            "id": id,
            "label": label,
            "options": options,
                   }
        return radio_dict
    
    def text(self,id,label,value):
        text_dict = {
           "input_type": "text",
            "id": id,
            "label": label,
            "value": value,
                   }
        return text_dict
    
    def number(self,id,label,value):
        number_dict = {
           "input_type": "number",
            "id": id,
            "label": label,
            "value": value,
                   }
        return number_dict

    def action(self,name,variant,type,action,action_flag_type):
        action_dict = {
                "name": name,
                "variant": variant,
                 "type": type,
                 "action": action,
                 "action_flag_type": action_flag_type
        }
        return action_dict



    def create_simulator(self,data,actions=[]) :
        try:
            sim_dict = {}
            sim_dict['isRevampedSim'] = True
            sim_dict['simulator_options']={}
            sim_dict['simulator_options']['sections']=data
            sim_dict['simulator_options']['section_orientation']="Horizontal"
            sim_dict['simulator_options']['actions']=actions
            return sim_dict
        except Exception as ex:
            logging.exception(ex)
            raise GeneralException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                message={"error": ScenariosErrors.LIST_SCENARIOS_ERROR.value},
            )  