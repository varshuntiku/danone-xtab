import logging
from abc import ABC, abstractmethod

from botocore.exceptions import BotoCoreError, ClientError


class S3UploadHandler(ABC):
    @abstractmethod
    async def handle(self, s3_client, resource_name, resource_path, local_file_path=None, file_stream=None, data=None):
        pass


class LocalFileS3UploadHandler(S3UploadHandler):
    async def handle(self, s3_client, resource_name, resource_path, local_file_path=None, file_stream=None, data=None):
        if local_file_path:
            try:
                with open(local_file_path, "rb") as source_file:
                    s3_client.upload_fileobj(source_file, resource_name, resource_path)
                return True
            except (BotoCoreError, ClientError) as e:
                logging.error(f"Error uploading local file to S3: {e}")
        return False


class StreamS3UploadHandler(S3UploadHandler):
    async def handle(self, s3_client, resource_name, resource_path, local_file_path=None, file_stream=None, data=None):
        if file_stream:
            try:
                s3_client.upload_fileobj(file_stream, resource_name, resource_path)
                return True
            except (BotoCoreError, ClientError) as e:
                logging.error(f"Error uploading file stream to S3: {e}")
        return False


class DataS3UploadHandler(S3UploadHandler):
    def handle(self, s3_client, resource_name, resource_path, local_file_path=None, file_stream=None, data=None):
        if data:
            try:
                s3_client.put_object(Bucket=resource_name, Key=resource_path, Body=data)
                return True
            except (BotoCoreError, ClientError) as e:
                logging.error(f"Error uploading raw data to S3: {e}")
        return False
